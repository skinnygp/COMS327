//
//  main.c
//  Dungeon
//
//  Created by Wang Wang on 15-2-23.
//  Copyright (c) 2015年 Wang Wang. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
