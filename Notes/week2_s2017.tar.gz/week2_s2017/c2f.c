#include "fc.h"

int c2f(int c)
{
  return ((9 * c) / 5) + 32;
}
