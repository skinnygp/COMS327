#include "fc.h"

int f2c(int f)
{
  return ((f - 32) * 5) / 9;
}
