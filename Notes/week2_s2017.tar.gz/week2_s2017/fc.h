#ifndef FC_H /* header guard */
# define FC_H

int f2c(int);
int c2f(int);

#endif
