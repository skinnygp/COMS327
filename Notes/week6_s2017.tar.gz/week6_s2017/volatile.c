int main(int argc, char *argv[])
{
  int i = 1;

  while (i)
    ;

  return 0;
}
