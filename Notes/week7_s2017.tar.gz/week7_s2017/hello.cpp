#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
  int i;

  i = 5;

  cout << "Hello " << i << " World!" << endl;

  return 0;
}
